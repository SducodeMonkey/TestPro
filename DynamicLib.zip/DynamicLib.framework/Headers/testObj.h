//
//  testObj.h
//  DynamicLib
//
//  Created by junmo on 16/11/9.
//  Copyright © 2016年 junmo. All rights reserved.
//

#ifndef testObj_h
#define testObj_h

@interface testObj : NSObject

- (int)add:(int)a with:(int)b;

@end

#endif /* testObj_h */
