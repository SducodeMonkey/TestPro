//
//  DynamicLib.h
//  DynamicLib
//
//  Created by junmo on 16/11/9.
//  Copyright © 2016年 junmo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DynamicLib.
FOUNDATION_EXPORT double DynamicLibVersionNumber;

//! Project version string for DynamicLib.
FOUNDATION_EXPORT const unsigned char DynamicLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DynamicLib/PublicHeader.h>

#import "testObj.h"
